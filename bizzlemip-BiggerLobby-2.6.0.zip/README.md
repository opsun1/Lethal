
# BiggerLobby V2.6.0

Allows up to 40 players to join lobbies.

Thank you guys for six hundred downloads! It really means a lot! I'm really glad I could make something so many people enjoyed.

## FAQ
> Q: Does everybody in the lobby need to have this mod?

A: Yes, everybody needs the mod installed. Make sure you're all updated to the latest version, too!

## Roadmap

Optimization

Dynamic voice chat culling

Dynamic VOIP sample rate.

##

[Discord Server](https://discord.gg/lcmods)